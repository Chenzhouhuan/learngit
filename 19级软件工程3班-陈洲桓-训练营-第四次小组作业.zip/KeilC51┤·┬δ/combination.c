#include<reg51.h>
#include<intrins.h>
#define uchar unsigned char
#define uint unsigned int 

sbit bee=P2^3;

//��������ܱ����
uchar code table2[] =
{0x3f,0x06,0x5b,0x4f,
0x66,0x6d,0x7d,0x07,
0x7f,0x6f,0x77,0x7c,
0x39,0x5e,0x79,0x71};

//��ʱ����
void mdelay(unsigned int t){
  unsigned char n;
  for(;t>0;t--)
    for(n=0;n<125;n++){;}
}

int main(){
	uchar k,i;
    while(1){
	bee=0;
	i=0;
	//��ˮ��
	k=0x01;	   //00000001
	for(i=0;i<8;i++){
	P1=k;
	mdelay(1000);
	k=k<<1;		   //00000010
	k=k|0x00;	   //00000001
	}

    mdelay(10000);
	//������
	bee=1;
	mdelay(1000);
	bee=0;

	//������
	P0=0x00;
	//P1=0x00;
	for(i=0;i<10;++i)
   {

    P0 = table2[i];
    //P1 = table2[i];
    mdelay(1500);
   } 
    mdelay(10000);
  }
}
#include "../head/linkedList.h"
#include<stdlib.h>
#include<stdio.h>


int hello(){
    printf("hello");
}
/**
 *  @name        : Status InitList(LinkList *L);
 *	@description : initialize an empty linked list with only the head node without value
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList(LinkedList *L) {
    *L = (LinkedList)malloc(sizeof(LinkedList));
	if(!(*L))
		return ERROR;
	(*L)->next =NULL;
	return SUCCESS;
}

/**
 *  @name        : void DestroyList(LinkedList *L)
 *	@description : destroy a linked list, free all the nodes
 *	@param		 : L(the head node)
 *	@return		 : None
 *  @notice      : None
 */
void DestroyList(LinkedList *L) {
  LinkedList p;
  while(*L)
  {
      p=*L;
      *L=(*L)->next;
      free(p);
  }
  p=NULL;
  *L=NULL;
  printf("������ɣ�");
}

/**
 *  @name        : Status InsertList(LNode *p, LNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : Status
 *  @notice      : None
 */
Status InsertList(LNode *p, LNode *q) {
  LNode *t;
  t=p->next;
  p->next=q;
  q->next=t;
}
/**
 *  @name        : Status DeleteList(LNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : Status
 *  @notice      : None
 */
Status DeleteList(LNode *p, ElemType *e) {
  LNode *q;
  q=p->next;
  *e=q->data;
  p->next=q->next;
}

/**
 *  @name        : void TraverseList(LinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : None
 *  @notice      : None
 */
void TraverseList(LinkedList L, void (*visit)(ElemType e)) {
  LinkedList a;
  a=L;
  while(a->data!=0)
  {
      visit(a->data);
      a=a->next;
  }
  printf("\n");
}
void visit(ElemType e)
{
    printf("%d\t",e);
}



/**
 *  @name        : Status SearchList(LinkedList L, ElemType e)
 *	@description : find the first node in the linked list according to e
 *	@param		 : L(the head node), e
 *	@return		 : Status
 *  @notice      : None
 */
Status SearchList(LinkedList L, ElemType e) {
  LinkedList a;
  a=L;
  while(L)
  {
      if(L->data==e)
        {
            printf("�����д��ڴ�����\n");
            return SUCCESS;
        }
      else
        L=L->next;
  }
  printf("��Ǹ�������в����ڴ�����\n");
  return ERROR;
}

/**
 *  @name        : Status ReverseList(LinkedList *L)
 *	@description : reverse the linked list
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status ReverseList(LinkedList *L) {
  LinkedList p,t;
  p=0;
  t=(*L)->next;
  while((*L)->data!=0)
   {
     (*L)->next=p;
     p=*L;
     *L=t;
     t=(*L)->next;
   }
   *L=p;
}

/**
 *  @name        : Status IsLoopList(LinkedList L)
 *	@description : judge whether the linked list is looped
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status IsLoopList(LinkedList L) {
  LinkedList a,b;
  int k=0;
  a=L;
  b=L;
  while(b&&b->next&&b->next->next)
  {
      b=b->next->next;
      a=a->next;
      if(b->data==a->data) k=1;
  }
  if(k==0) printf("There isn't looped.\n");
  if(k==1) printf("There is looped.\n");
}

/**
 *  @name        : LNode* ReverseEvenList(LinkedList *L)
 *	@description : reverse the nodes which value is an even number in the linked list, input: 1 -> 2 -> 3 -> 4  output: 2 -> 1 -> 4 -> 3
 *	@param		 : L(the head node)
 *	@return		 : LNode(the new head node)
 *  @notice      : choose to finish
 */
LNode* ReverseEvenList(LinkedList *L) {
  LinkedList s,t,q,a,b,c;
  int k=0;
  a=*L;
  while(a->data!=0)
  {
      k++;
      a=a->next;
  }
  a=*L;
  s=*L;
  *L=s->next;
  while(s&&s->next)
  {
      t=s->next;
      q=t->next;
      if(t->next&&t->next->next) { s->next=t->next->next; }
      else { s->next=t->next; }
      t->next=s;
      s=q;
  }
  if((k-k/2*2)==1)
  {
     while(a->data!=0) { c=a; a=a->next; }
     b=a;
     a=a->next;
     a->next=b;
     c->next=a;
     b->next=0;
  }
  return *L;
}

/**
 *  @name        : LNode* FindMidNode(LinkedList *L)
 *	@description : find the middle node in the linked list
 *	@param		 : L(the head node)
 *	@return		 : LNode
 *  @notice      : choose to finish
 */
LNode* FindMidNode(LinkedList *L) {
  LinkedList a;
  int i,k=0;
  a=*L;
  while(a)
  {
      a=a->next;
      k++;
  }
  k--;
  a=*L;
  for(i=0;i<k/2;i++)
  {
      a=a->next;
  }
  return a;
}


#include "..\head\count.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void){
  User();
  return 0;
}
